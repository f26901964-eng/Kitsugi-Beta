package com.lagradost.api

import kotlin.String

public object BuildConfig {
  public val MDL_API_KEY: String = "null"

  public val TRAKT_CLIENT_ID: String = "null"
}
