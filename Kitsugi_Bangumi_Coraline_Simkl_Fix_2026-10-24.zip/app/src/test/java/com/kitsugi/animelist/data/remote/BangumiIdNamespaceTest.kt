package com.kitsugi.animelist.data.remote

import com.kitsugi.animelist.data.auth.BangumiApiClient
import com.kitsugi.animelist.model.MediaType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.json.JSONObject

class BangumiIdNamespaceTest {
    @Test
    fun `Bangumi subject types and platform map to supported Kitsugi types`() {
        assertEquals(MediaType.Anime, BangumiIdNamespace.mediaTypeFor(BangumiApiClient.SubjectType.ANIME, "TV"))
        assertEquals(MediaType.Movie, BangumiIdNamespace.mediaTypeFor(BangumiApiClient.SubjectType.ANIME, "剧场版"))
        assertEquals(MediaType.Manga, BangumiIdNamespace.mediaTypeFor(BangumiApiClient.SubjectType.BOOK, "漫画"))
        assertEquals(MediaType.TvShow, BangumiIdNamespace.mediaTypeFor(BangumiApiClient.SubjectType.REAL, "电视剧"))
        assertEquals(MediaType.Movie, BangumiIdNamespace.mediaTypeFor(BangumiApiClient.SubjectType.REAL, "电影"))
    }

    @Test
    fun `unsupported subject types are not treated as anime`() {
        assertFalse(BangumiIdNamespace.supportsSubjectType(BangumiApiClient.SubjectType.GAME))
        assertFalse(BangumiIdNamespace.supportsSubjectType(BangumiApiClient.SubjectType.MUSIC))
        assertFalse(BangumiIdNamespace.supportsSubjectType(0))
    }

    @Test
    fun `media type maps back to the correct Bangumi subject type`() {
        assertEquals(BangumiApiClient.SubjectType.ANIME, BangumiIdNamespace.subjectTypeFor(MediaType.Anime))
        assertEquals(BangumiApiClient.SubjectType.BOOK, BangumiIdNamespace.subjectTypeFor(MediaType.Manga))
        assertEquals(BangumiApiClient.SubjectType.REAL, BangumiIdNamespace.subjectTypeFor(MediaType.Movie))
        assertEquals(BangumiApiClient.SubjectType.REAL, BangumiIdNamespace.subjectTypeFor(MediaType.TvShow))
    }

    @Test
    fun `movie platform mapping is explicit`() {
        assertTrue(BangumiIdNamespace.isMoviePlatform("电影"))
        assertTrue(BangumiIdNamespace.isMoviePlatform("劇場版"))
        assertFalse(BangumiIdNamespace.isMoviePlatform("电视剧"))
    }

    @Test
    fun `movie identity search accepts animated and live action films but not TV subjects`() {
        assertEquals(
            listOf(BangumiApiClient.SubjectType.ANIME, BangumiApiClient.SubjectType.REAL),
            BangumiIdNamespace.subjectTypesFor(MediaType.Movie)
        )

        // Canlı Bangumi kaydı: Coraline #103470, type=2 (ANIME), platform=剧场版.
        assertTrue(
            BangumiIdNamespace.isCompatibleWithMediaType(
                MediaType.Movie,
                BangumiApiClient.SubjectType.ANIME,
                "剧场版"
            )
        )
        assertTrue(
            BangumiIdNamespace.isCompatibleWithMediaType(
                MediaType.Movie,
                BangumiApiClient.SubjectType.REAL,
                "电影"
            )
        )
        assertFalse(
            BangumiIdNamespace.isCompatibleWithMediaType(
                MediaType.Movie,
                BangumiApiClient.SubjectType.ANIME,
                "TV"
            )
        )
        assertFalse(
            BangumiIdNamespace.isCompatibleWithMediaType(
                MediaType.Movie,
                BangumiApiClient.SubjectType.REAL,
                "电视剧"
            )
        )
        assertFalse(
            BangumiIdNamespace.isCompatibleWithMediaType(
                MediaType.Movie,
                BangumiApiClient.SubjectType.BOOK,
                "漫画"
            )
        )
    }

    @Test
    fun `Coraline search selects Bangumi animated movie 103470 and rejects TV decoys`() {
        val coraline = subject(
            id = 103_470,
            type = BangumiApiClient.SubjectType.ANIME,
            platform = "剧场版",
            nameCn = "鬼妈妈"
        )
        val animeTvDecoy = subject(
            id = 103_469,
            type = BangumiApiClient.SubjectType.ANIME,
            platform = "TV"
        )
        val realTvDecoy = subject(
            id = 103_471,
            type = BangumiApiClient.SubjectType.REAL,
            platform = "电视剧"
        )

        val selected = BangumiIdNamespace.selectUniqueSubjectMatch(
            subjects = listOf(animeTvDecoy, coraline, realTvDecoy),
            query = "Coraline",
            expectedYear = 2009,
            expectedSubjectTypes = BangumiIdNamespace.subjectTypesFor(MediaType.Movie),
            mediaType = MediaType.Movie
        )

        assertEquals(103_470, selected?.id)
    }

    private fun subject(id: Int, type: Int, platform: String, nameCn: String = "") =
        BangumiApiClient.parseSubject(
            JSONObject().apply {
                put("id", id)
                put("type", type)
                put("name", "Coraline")
                put("name_cn", nameCn)
                put("date", "2009-02-06")
                put("platform", platform)
            }
        )
}
