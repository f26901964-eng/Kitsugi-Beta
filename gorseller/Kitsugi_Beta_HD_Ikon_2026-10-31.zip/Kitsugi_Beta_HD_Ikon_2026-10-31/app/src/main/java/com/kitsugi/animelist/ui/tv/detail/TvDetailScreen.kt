package com.kitsugi.animelist.ui.tv.detail

import android.view.KeyEvent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import com.kitsugi.animelist.ui.components.KitsugiEmojiLabel
import com.kitsugi.animelist.ui.theme.gradient.background
import com.kitsugi.animelist.ui.theme.gradient.border
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import com.kitsugi.animelist.ui.icons.KitsugiIcons as Icons
import androidx.compose.ui.platform.LocalContext
import com.kitsugi.animelist.ui.components.KitsugiUiverseGlowButton
import com.kitsugi.animelist.ui.theme.gradient.Icon
import androidx.compose.material3.MaterialTheme
import com.kitsugi.animelist.ui.theme.gradient.Text
import androidx.compose.ui.res.stringResource
import com.kitsugi.animelist.R
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import androidx.compose.runtime.*
import androidx.compose.runtime.withFrameNanos
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kitsugi.animelist.ui.components.PlatformErrorExplanationBlock
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusRestorer
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kitsugi.animelist.data.fandom.FandomMediaQueries
import com.kitsugi.animelist.ui.screens.detail.wiki.FandomMediaWikiViewModel
import com.kitsugi.animelist.ui.screens.detail.wiki.MediaWikiSectionCard
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.LocalBringIntoViewSpec
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.tv.material3.ExperimentalTvMaterial3Api
import coil3.compose.AsyncImage
import com.kitsugi.animelist.data.remote.JikanApiClient
import com.kitsugi.animelist.data.remote.JikanSearchResult
import com.kitsugi.animelist.data.remote.KitsugiCharacter
import com.kitsugi.animelist.data.remote.KitsugiRelation
import com.kitsugi.animelist.data.remote.KitsugiReview
import com.kitsugi.animelist.data.remote.KitsugiStaff
import com.kitsugi.animelist.data.remote.KitsugiStats
import com.kitsugi.animelist.data.remote.KitsugiStreamingEpisode
import com.kitsugi.animelist.model.MediaEntry
import com.kitsugi.animelist.model.MediaType
import com.kitsugi.animelist.ui.screens.detail.ApiResultDetailViewModel
import com.kitsugi.animelist.ui.screens.detail.DetailTabState
import com.kitsugi.animelist.ui.screens.detail.DetailTvPeopleRailSkeleton
import com.kitsugi.animelist.ui.screens.detail.DetailTvRelationsRailSkeleton
import com.kitsugi.animelist.ui.screens.detail.DetailTvEpisodesRailSkeleton
import com.kitsugi.animelist.ui.screens.detail.DetailStatsLoadingSkeleton
import com.kitsugi.animelist.ui.theme.LocalKitsugiAccent
import com.kitsugi.animelist.ui.theme.KitsugiColors
import com.kitsugi.animelist.ui.theme.KitsugiTvTokens
import com.kitsugi.animelist.ui.utils.KitsugiScrollDefaults
import com.kitsugi.animelist.ui.utils.requestFocusAfterFrames
import com.kitsugi.animelist.ui.utils.dpadVerticalFastScroll
import com.kitsugi.animelist.ui.tv.input.isSelectKey
import com.kitsugi.animelist.ui.utils.requestFocusAfterFrames
import com.kitsugi.animelist.ui.utils.tvClickable
import com.kitsugi.animelist.utils.PreferenceHelpers.getDisplayTitle
import com.kitsugi.animelist.ui.tv.focus.TvFocusRestoration.safeRequestFocus
import com.kitsugi.animelist.ui.components.KitsugiCinematicLoadingScreen
import com.kitsugi.animelist.utils.toTurkishStaffRole
import com.kitsugi.animelist.utils.toTurkishRelationType
import com.kitsugi.animelist.utils.toTurkishCharacterRole
import com.kitsugi.animelist.ui.components.safeBlur
import com.kitsugi.animelist.utils.KitsugiStrings

@OptIn(ExperimentalTvMaterial3Api::class, ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class)
@Composable
fun TvDetailScreen(
    result: JikanSearchResult,
    existingEntry: MediaEntry?,
    onBackClick: () -> Unit,
    onPlayEpisodeClick: (episode: KitsugiStreamingEpisode, season: Int, synonyms: List<String>, tmdbId: Int?) -> Unit,
    onPlayMovieClick: (synonyms: List<String>, tmdbId: Int?) -> Unit,
    onToggleLibrary: () -> Unit,
    onNavigateToRelationDetail: (JikanSearchResult) -> Unit,
    onCharacterClick: (characterId: Int, source: String, name: String?, imageUrl: String?) -> Unit,
    onStaffClick: (staffId: Int, source: String, name: String?, imageUrl: String?) -> Unit,
    titleLanguage: String = "ROMAJI",
    viewModel: ApiResultDetailViewModel = viewModel()
) {
    val accentColor = LocalKitsugiAccent.current

    LaunchedEffect(result.source, result.malId, result.type) {
        viewModel.loadResult(result, showAnimeLogos = true)
    }

    val detailState by viewModel.detailState.collectAsStateWithLifecycle()
    val detailLoading by viewModel.detailLoading.collectAsStateWithLifecycle()
    val detailErrorCode by viewModel.detailErrorCode.collectAsStateWithLifecycle()
    val translatedSynopsis by viewModel.translatedSynopsis.collectAsStateWithLifecycle()
    val charactersState by viewModel.charactersState.collectAsStateWithLifecycle()
    val staffState by viewModel.staffState.collectAsStateWithLifecycle()
    val relationsState by viewModel.relationsState.collectAsStateWithLifecycle()
    val episodesState by viewModel.episodesState.collectAsStateWithLifecycle()
    val targetSeason by viewModel.targetSeason.collectAsStateWithLifecycle()
    val logoUrl by viewModel.logoUrl.collectAsStateWithLifecycle()
    val episodeRatings by viewModel.episodeRatings.collectAsStateWithLifecycle()
    val reviewsState by viewModel.reviewsState.collectAsStateWithLifecycle()
    val statsState by viewModel.statsState.collectAsStateWithLifecycle()

    LaunchedEffect(detailState) {
        if (detailState != null) {
            viewModel.loadTab(2, result, result.realMalId ?: detailState?.realMalId) // Karakterler
            viewModel.loadTab(3, result, result.realMalId ?: detailState?.realMalId) // Ekip
            viewModel.loadTab(5, result, result.realMalId ?: detailState?.realMalId) // İlişkiler
            viewModel.loadTab(6, result, result.realMalId ?: detailState?.realMalId) // Grafikler (stats)
            viewModel.loadTab(7, result, result.realMalId ?: detailState?.realMalId) // Yorumlar (reviews)
            viewModel.loadTab(8, result, result.realMalId ?: detailState?.realMalId) // Bölümler (episodes)
        }
    }

    val displayResult = remember(result, detailState) {
        val detail = detailState
        if (detail != null) {
            result.copy(
                title = detail.titleRomaji ?: (if (result.title == KitsugiStrings.get(R.string.loading) || result.title == "Loading...") (detail.title ?: result.title) else result.title),
                titleEnglish = detail.titleEnglish ?: result.titleEnglish,
                titleJapanese = (detail.titleJapanese ?: detail.titleNative) ?: result.titleJapanese,
                titleRomaji = detail.titleRomaji ?: result.titleRomaji,
                imageUrl = result.imageUrl ?: detail.imageUrl,
                score = result.score ?: detail.score,
                year = result.year ?: detail.year,
                total = result.total ?: detail.total,
                isAdult = result.isAdult || detail.isAdult,
                realMalId = result.realMalId ?: detail.realMalId
            )
        } else {
            result
        }
    }

    val displayTitle = displayResult.getDisplayTitle(titleLanguage)
    val displaySynopsis = translatedSynopsis ?: detailState?.synopsis ?: ""
    val isMovie = displayResult.type == MediaType.Movie

    // Fandom Wiki (TV): telefondaki sekmenin karşılığı, listenin sonunda açılır kart.
    val wikiViewModel: FandomMediaWikiViewModel = viewModel(key = "fandom_tv_${result.source}_${result.malId}_${result.type.name}")
    val wikiQuery = remember(result, displayResult, detailState) {
        val imdbId = detailState?.externalLinks
            ?.firstOrNull { it.site.contains("IMDb", ignoreCase = true) || it.url.contains("imdb.com", ignoreCase = true) }
            ?.url?.let { Regex("(?i)tt[0-9]{5,12}").find(it)?.value }
        val wikidataId = detailState?.externalLinks
            ?.firstOrNull { it.site.contains("Wikidata", ignoreCase = true) || it.url.contains("wikidata.org", ignoreCase = true) }
            ?.url?.let { Regex("(?i)Q[0-9]+").find(it)?.value }
        FandomMediaQueries.fromMedia(
            source = result.source,
            mediaId = result.malId,
            malId = displayResult.realMalId ?: detailState?.realMalId,
            tmdbId = displayResult.tmdbId ?: detailState?.tmdbId,
            isManga = displayResult.type == MediaType.Manga,
            isMovie = isMovie,
            isTvShow = !isMovie,
            releaseYear = displayResult.year ?: detailState?.year,
            imdbId = imdbId,
            wikidataId = wikidataId,
            format = detailState?.format,
            rawFormat = detailState?.rawFormat,
            subtitle = displayResult.subtitle,
            titles = (
                listOfNotNull(
                    displayResult.titleEnglish,
                    displayResult.title,
                    displayResult.titleRomaji,
                    displayResult.titleJapanese,
                    detailState?.titleNative,
                    detailState?.titleJapanese,
                    detailState?.titleEnglish,
                    detailState?.titleTurkish
                ) + detailState?.synonyms.orEmpty()
            )
        )
    }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val trailerService = remember { com.kitsugi.animelist.data.trailer.TrailerServiceHolder.get(context) }
    val apiClient = remember { JikanApiClient() }

    var showTrailerOverlay by remember { mutableStateOf(false) }
    var trailerPlaybackSource by remember { mutableStateOf<com.kitsugi.animelist.data.trailer.TrailerPlaybackSource?>(null) }
    var trailerLoading by remember { mutableStateOf(false) }
    var trailerError by remember { mutableStateOf<String?>(null) }
    var trailerOverlayTitle by remember { mutableStateOf("") }

    val loadAndShowTrailer = {
        trailerOverlayTitle = displayTitle
        val tmdbIdStr = displayResult.tmdbId?.toString() ?: detailState?.tmdbId?.toString()
        if (tmdbIdStr == null && displayResult.title.isBlank()) {
            trailerError = context.getString(R.string.tv_detail_trailer_info_not_found)
            showTrailerOverlay = true
        } else {
            showTrailerOverlay = true
            trailerLoading = true
            trailerError = null
            trailerPlaybackSource = null
            scope.launch {
                try {
                    val source = trailerService.getTrailerPlaybackSource(
                        title = displayResult.title,
                        year = displayResult.year?.toString(),
                        tmdbId = tmdbIdStr,
                        type = if (displayResult.type == MediaType.Movie) "movie" else "tv"
                    )
                    if (source != null && !source.videoUrl.isBlank()) {
                        trailerPlaybackSource = source
                    } else {
                        trailerError = context.getString(R.string.tv_detail_trailer_not_found)
                    }
                } catch (e: Exception) {
                    trailerError = context.getString(R.string.tv_detail_trailer_load_error, e.message ?: "")
                } finally {
                    trailerLoading = false
                }
            }
        }
    }

    val playButtonFocusRequester = remember { FocusRequester() }
    val libraryButtonFocusRequester = remember { FocusRequester() }
    val trailerButtonFocusRequester = remember { FocusRequester() }
    val seasonTabsFocusRequester = remember { FocusRequester() }
    val episodesRowFocusRequester = remember { FocusRequester() }
    val themesRowFocusRequester = remember { FocusRequester() }
    val charactersRowFocusRequester = remember { FocusRequester() }
    val staffRowFocusRequester = remember { FocusRequester() }
    val relationsRowFocusRequester = remember { FocusRequester() }
    val statsRowFocusRequester = remember { FocusRequester() }
    val reviewsRowFocusRequester = remember { FocusRequester() }

    // Track which focusable row sections are actually rendered/attached.
    // focusProperties must never reference a FocusRequester that has no
    // corresponding Modifier.focusRequester() node in the tree — doing so
    // causes an IllegalStateException crash on D-pad key events.
    val hasSeasonTabs = !isMovie && (detailState?.totalSeasons ?: 1) > 1
    val hasEpisodesRow = !isMovie &&
        episodesState is DetailTabState.Success &&
        ((episodesState as DetailTabState.Success<*>).data as? List<*>)?.isNotEmpty() == true
    val hasThemesRow = detailState != null && 
        (detailState?.openings?.isNotEmpty() == true || detailState?.endings?.isNotEmpty() == true)
    val hasCharactersRow = charactersState is DetailTabState.Success &&
        ((charactersState as DetailTabState.Success<*>).data as? List<*>)?.isNotEmpty() == true
    val hasStaffRow = staffState is DetailTabState.Success &&
        ((staffState as DetailTabState.Success<*>).data as? List<*>)?.isNotEmpty() == true
    val hasRelationsRow = relationsState is DetailTabState.Success &&
        ((relationsState as DetailTabState.Success<*>).data as? List<*>)?.isNotEmpty() == true
    val hasStatsRow = statsState is DetailTabState.Success
    val hasReviewsRow = reviewsState is DetailTabState.Success &&
        ((reviewsState as DetailTabState.Success<*>).data as? List<*>)?.isNotEmpty() == true

    BackHandler {
        onBackClick()
    }

    val detailFocusRequester = remember { FocusRequester() }
    com.kitsugi.animelist.ui.tv.focus.TvGlobalFocusRecovery(fallbackFocusRequester = playButtonFocusRequester)

    LaunchedEffect(detailLoading) {
        if (!detailLoading) {
            playButtonFocusRequester.requestFocusAfterFrames(frames = 3)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(KitsugiColors.Background)
            .focusRequester(detailFocusRequester)
    ) {
        // 1. Fullscreen Backdrop with Gradients
        val backdropUrl = displayResult.backdropUrl ?: displayResult.imageUrl
        if (!backdropUrl.isNullOrBlank()) {
            com.kitsugi.animelist.ui.components.KitsugiNsfwImage(
                model = backdropUrl,
                contentDescription = null,
                isAdult = displayResult.isAdult,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(alpha = 0.3f),
                contentScale = ContentScale.Crop
            )

            // Dynamic gradients to protect text legibility
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                KitsugiColors.Background,
                                KitsugiColors.Background.copy(alpha = 0.9f),
                                KitsugiColors.Background.copy(alpha = 0.6f),
                                Color.Transparent
                            ),
                            startX = 0f,
                            endX = 1600f
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                KitsugiColors.Background.copy(alpha = 0.4f),
                                KitsugiColors.Background
                            )
                        )
                    )
            )
        }

        if (detailLoading) {
            KitsugiCinematicLoadingScreen(
                title = displayTitle,
                imageUrl = displayResult.imageUrl,
                logoUrl = logoUrl,
                isAdult = displayResult.isAdult,
                source = displayResult.source,
                onBackClick = onBackClick,
                platformErrorCode = detailErrorCode
            )
        } else {
            val mainLazyListState = rememberLazyListState()

            CompositionLocalProvider(
                LocalBringIntoViewSpec provides KitsugiScrollDefaults.rememberTvCenteredSpec()
            ) {
                LazyColumn(
                    state = mainLazyListState,
                    modifier = Modifier
                        .fillMaxSize()
                        .dpadVerticalFastScroll(scrollableState = mainLazyListState),
                    contentPadding = PaddingValues(
                        horizontal = KitsugiTvTokens.Spacing.screenHorizontal,
                        vertical = KitsugiTvTokens.Spacing.screenVertical
                    ),
                    verticalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.rowGap)
                ) {
                    // --- Kaynak hatası: detay alınamadığında kod ve açıklama ---
                    if (detailState == null) {
                        detailErrorCode?.let { code ->
                            item {
                                PlatformErrorExplanationBlock(
                                    code = code,
                                    tint = KitsugiColors.AccentRed,
                                    modifier = Modifier.fillMaxWidth(0.65f)
                                )
                            }
                        }
                    }

                    // --- Hero Section ---
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth(0.65f)
                                .padding(top = KitsugiTvTokens.Spacing.contentPadding),
                            verticalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.md)
                        ) {
                            if (!logoUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = logoUrl,
                                    contentDescription = displayTitle,
                                    modifier = Modifier
                                        .height(90.dp)
                                        .fillMaxWidth(),
                                    contentScale = ContentScale.Fit,
                                    alignment = Alignment.CenterStart
                                )
                            } else {
                                Text(
                                    text = displayTitle,
                                    style = MaterialTheme.typography.headlineLarge.copy(
                                        fontWeight = FontWeight.Black,
                                        fontSize = 36.sp
                                    ),
                                    color = KitsugiColors.TextPrimary,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            // Meta Badges Row
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.sm),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                BadgeText(
                                    text = when (displayResult.type) {
                                        MediaType.Anime -> stringResource(R.string.tv_detail_type_anime)
                                        MediaType.Movie -> stringResource(R.string.tv_detail_type_movie)
                                        MediaType.TvShow -> stringResource(R.string.tv_detail_type_tv)
                                        else -> stringResource(R.string.tv_detail_type_manga)
                                    }
                                )
                                if (displayResult.year != null) {
                                    BadgeText(text = displayResult.year.toString())
                                }
                                if (displayResult.score != null && displayResult.score > 0) {
                                    KitsugiEmojiLabel(label = "%.1f".format(displayResult.score.toDouble()), icon = Icons.StarSolid, iconSize = 11.dp, color = LocalContentColor.current, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                                if (displayResult.isAdult) {
                                    BadgeText(text = "18+", color = Color(0xFFD32F2F))
                                }
                            }

                            // Synopsis
                            Text(
                                text = displaySynopsis,
                                style = MaterialTheme.typography.bodyMedium,
                                color = KitsugiColors.TextSecondary,
                                maxLines = 4,
                                overflow = TextOverflow.Ellipsis,
                                lineHeight = 22.sp
                            )

                            // Genres + Studios (spoiler türler vitrinde gizlenir)
                            val detailTags = detailState?.tags.orEmpty()
                            val genres = detailState?.genres.orEmpty()
                                .filterNot { com.kitsugi.animelist.utils.KitsugiSpoilerRules.isGenreSpoiler(it, detailTags) }
                            val studios = detailState?.studios.orEmpty().filter { it.isMain }.map { it.name }
                            if (genres.isNotEmpty() || studios.isNotEmpty()) {
                                androidx.compose.foundation.lazy.LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    contentPadding = PaddingValues(vertical = 2.dp)
                                ) {
                                    items(studios) { studio ->
                                        BadgeText(text = studio, color = accentColor)
                                    }
                                    items(genres.take(6)) { genre ->
                                        BadgeText(text = genre)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(KitsugiTvTokens.Spacing.sm))

                            // Action Buttons Row
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.contentPadding),
                                modifier = Modifier.focusGroup()
                            ) {
                                val totalSeasons = detailState?.totalSeasons ?: 1
                                val hasMultipleSeasons = totalSeasons > 1

                                TvActionButton(
                                    onClick = {
                                        if (isMovie) {
                                            com.kitsugi.animelist.core.player.TvTrailerPlayerPoolHolder.get(context).yield()
                                            onPlayMovieClick(detailState?.synonyms.orEmpty(), detailState?.tmdbId ?: displayResult.tmdbId)
                                        } else {
                                            try {
                                                if (hasMultipleSeasons && hasSeasonTabs) {
                                                    seasonTabsFocusRequester.requestFocus()
                                                } else if (hasEpisodesRow) {
                                                    episodesRowFocusRequester.requestFocus()
                                                }
                                            } catch (_: IllegalStateException) {
                                                // FocusRequester henüz init edilmemiş — veri yüklenirken
                                                // güvenle görmezden gel
                                            }
                                        }
                                    },
                                    focusRequester = playButtonFocusRequester,
                                    text = if (isMovie) stringResource(R.string.tv_detail_play) else stringResource(R.string.tv_detail_select_episode),
                                    icon = Icons.PlayArrow,
                                    backgroundColor = accentColor,
                                    textColor = Color.White,
                                    modifier = Modifier.focusProperties {
                                        right = libraryButtonFocusRequester
                                        // FocusRequester.Cancel: Compose focus sistemine
                                        // "bu yönde geçiş yapma" der ve uninit requester
                                        // crash'ini tamamen engeller.
                                        down = when {
                                            !isMovie && hasSeasonTabs  -> seasonTabsFocusRequester
                                            !isMovie && hasEpisodesRow -> episodesRowFocusRequester
                                            hasThemesRow                -> themesRowFocusRequester
                                            hasCharactersRow            -> charactersRowFocusRequester
                                            else                        -> FocusRequester.Cancel
                                        }
                                    }
                                )

                                TvActionButton(
                                    onClick = onToggleLibrary,
                                    focusRequester = libraryButtonFocusRequester,
                                    text = if (existingEntry != null) stringResource(R.string.tv_detail_remove_library) else stringResource(R.string.tv_detail_add_library),
                                    icon = Icons.Bookmarks,
                                    backgroundColor = KitsugiColors.SurfaceStrong,
                                    textColor = KitsugiColors.TextPrimary,
                                    modifier = Modifier.focusProperties {
                                        left = playButtonFocusRequester
                                        right = trailerButtonFocusRequester
                                        down = when {
                                            !isMovie && hasSeasonTabs  -> seasonTabsFocusRequester
                                            !isMovie && hasEpisodesRow -> episodesRowFocusRequester
                                            hasThemesRow                -> themesRowFocusRequester
                                            hasCharactersRow            -> charactersRowFocusRequester
                                            else                        -> FocusRequester.Cancel
                                        }
                                    }
                                )

                                TvActionButton(
                                    onClick = { loadAndShowTrailer() },
                                    focusRequester = trailerButtonFocusRequester,
                                    text = stringResource(R.string.tv_detail_trailer),
                                    icon = Icons.Movie,
                                    backgroundColor = KitsugiColors.SurfaceStrong,
                                    textColor = KitsugiColors.TextPrimary,
                                    modifier = Modifier.focusProperties {
                                        left = libraryButtonFocusRequester
                                        down = when {
                                            !isMovie && hasSeasonTabs  -> seasonTabsFocusRequester
                                            !isMovie && hasEpisodesRow -> episodesRowFocusRequester
                                            hasThemesRow                -> themesRowFocusRequester
                                            hasCharactersRow            -> charactersRowFocusRequester
                                            else                        -> FocusRequester.Cancel
                                        }
                                    }
                                )
                            }
                        }
                    }

                    // --- Season Selection Tabs (For multiple seasons) ---
                    val totalSeasons = detailState?.totalSeasons ?: 1
                    if (!isMovie && totalSeasons > 1) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.sm)) {
                                Text(
                                    text = stringResource(R.string.tv_detail_seasons),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = KitsugiColors.TextPrimary
                                )

                                val seasonsList = remember(totalSeasons) { (1..totalSeasons).toList() }
                                LazyRow(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .focusRequester(seasonTabsFocusRequester)
                                        .focusRestorer()
                                        .focusGroup()
                                        .focusProperties {
                                            up = playButtonFocusRequester
                                            down = when {
                                                hasEpisodesRow   -> episodesRowFocusRequester
                                                hasThemesRow     -> themesRowFocusRequester
                                                hasCharactersRow -> charactersRowFocusRequester
                                                else             -> FocusRequester.Cancel
                                            }
                                        },
                                    horizontalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.itemGap),
                                    contentPadding = PaddingValues(vertical = 4.dp)
                                ) {
                                    items(seasonsList) { season ->
                                        val isSelected = season == targetSeason
                                        var isFocused by remember { mutableStateOf(false) }

                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(20.dp))
                                                .background(if (isSelected) accentColor else KitsugiColors.Surface)
                                                .border(
                                                    BorderStroke(
                                                        width = if (isFocused) KitsugiTvTokens.Cards.focusedBorderWidth else 0.dp,
                                                        color = if (isFocused) Color.White else Color.Transparent
                                                    ),
                                                    shape = RoundedCornerShape(20.dp)
                                                )
                                                .onFocusChanged { isFocused = it.isFocused }
                                                .tvClickable(shape = RoundedCornerShape(20.dp)) {
                                                    viewModel.setTargetSeason(season, result, result.realMalId ?: detailState?.realMalId)
                                                }
                                                .padding(horizontal = 20.dp, vertical = 10.dp)
                                        ) {
                                            Text(
                                                text = stringResource(R.string.tv_detail_season_label, season),
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                color = if (isSelected || isFocused) Color.White else KitsugiColors.TextSecondary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // --- Episodes Section ---
                    if (!isMovie) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.sm)) {
                                Text(
                                    text = stringResource(R.string.tv_detail_episodes),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = KitsugiColors.TextPrimary
                                )

                                when (val epState = episodesState) {
                                    is DetailTabState.Loading -> {
                                        DetailTvEpisodesRailSkeleton(itemCount = 4)
                                    }
                                    is DetailTabState.Success -> {
                                        val episodes = epState.data
                                        if (episodes.isEmpty()) {
                                            Text(
                                                text = stringResource(R.string.tv_detail_episodes_empty),
                                                color = KitsugiColors.TextMuted,
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                        } else {
                                            LazyRow(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .focusRequester(episodesRowFocusRequester)
                                                    .focusRestorer()
                                                    .focusGroup()
                                                    .focusProperties {
                                                        up = if (hasSeasonTabs) seasonTabsFocusRequester else playButtonFocusRequester
                                                        down = when {
                                                            hasThemesRow     -> themesRowFocusRequester
                                                            hasCharactersRow -> charactersRowFocusRequester
                                                            else             -> FocusRequester.Cancel
                                                        }
                                                    },
                                                horizontalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.itemGap),
                                                contentPadding = PaddingValues(vertical = 4.dp)
                                            ) {
                                                itemsIndexed(episodes) { index, episode ->
                                                    val episodeNumber = episode.episodeNumber ?: (index + 1)
                                                    val isWatched = (existingEntry?.progress ?: 0) >= episodeNumber
                                                    val ratingKey = targetSeason to episodeNumber
                                                    val rating = episodeRatings[ratingKey]
                                                        ?: episodeRatings[1 to episodeNumber]
                                                    TvEpisodeCard(
                                                        episode = episode,
                                                        index = index,
                                                        accentColor = accentColor,
                                                        rating = rating,
                                                        isWatched = isWatched,
                                                        isAdult = displayResult.isAdult,
                                                        onClick = {
                                                            com.kitsugi.animelist.core.player.TvTrailerPlayerPoolHolder.get(context).yield()
                                                            onPlayEpisodeClick(episode, targetSeason, detailState?.synonyms.orEmpty(), detailState?.tmdbId ?: displayResult.tmdbId)
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    else -> {}
                                }
                            }
                        }
                    }

                    // --- Characters Section ---
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.sm)) {
                            Text(
                                text = "Karakterler",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = KitsugiColors.TextPrimary
                            )

                            when (val charsState = charactersState) {
                                is DetailTabState.Loading -> {
                                    DetailTvPeopleRailSkeleton(itemCount = 6)
                                }
                                is DetailTabState.Success -> {
                                    val characters = charsState.data
                                    if (characters.isEmpty()) {
                                        Text(
                                            text = stringResource(R.string.tv_detail_characters_empty),
                                            color = KitsugiColors.TextMuted,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    } else {
                                        LazyRow(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .focusRequester(charactersRowFocusRequester)
                                                .focusRestorer()
                                                .focusGroup()
                                                .focusProperties {
                                                    up = when {
                                                        hasThemesRow                -> themesRowFocusRequester
                                                        !isMovie && hasEpisodesRow -> episodesRowFocusRequester
                                                        else                        -> playButtonFocusRequester
                                                    }
                                                    down = when {
                                                        hasStaffRow     -> staffRowFocusRequester
                                                        hasRelationsRow -> relationsRowFocusRequester
                                                        else            -> FocusRequester.Cancel
                                                    }
                                                },
                                            horizontalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.itemGap),
                                            contentPadding = PaddingValues(vertical = 4.dp)
                                        ) {
                                            items(characters) { char ->
                                                TvCharacterCard(
                                                    character = char,
                                                    onClick = {
                                                        onCharacterClick(char.id, displayResult.source, char.name, char.imageUrl)
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                                else -> {}
                             }
                        }
                    }

                    // --- Staff Section ---
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.sm)) {
                            Text(
                                text = stringResource(R.string.tv_detail_staff),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = KitsugiColors.TextPrimary
                            )

                            when (val stfState = staffState) {
                                is DetailTabState.Loading -> {
                                    DetailTvPeopleRailSkeleton(itemCount = 6, showRole = true)
                                }
                                is DetailTabState.Success -> {
                                    val staffList = stfState.data
                                    if (staffList.isEmpty()) {
                                        Text(
                                            text = stringResource(R.string.tv_detail_staff_empty),
                                            color = KitsugiColors.TextMuted,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    } else {
                                        LazyRow(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .focusRequester(staffRowFocusRequester)
                                                .focusRestorer()
                                                .focusGroup()
                                                .focusProperties {
                                                    up = when {
                                                        hasCharactersRow -> charactersRowFocusRequester
                                                        hasThemesRow     -> themesRowFocusRequester
                                                        !isMovie && hasEpisodesRow -> episodesRowFocusRequester
                                                        else             -> playButtonFocusRequester
                                                    }
                                                    down = if (hasRelationsRow) relationsRowFocusRequester else FocusRequester.Cancel
                                                },
                                            horizontalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.itemGap),
                                            contentPadding = PaddingValues(vertical = 4.dp)
                                        ) {
                                            items(staffList) { staff ->
                                                TvStaffCard(
                                                    staff = staff,
                                                    onClick = {
                                                        onStaffClick(staff.id, displayResult.source, staff.name, staff.imageUrl)
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                                else -> {}
                            }
                        }
                    }

                    // --- Relations Section ---
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.sm)) {
                            Text(
                                text = stringResource(R.string.tv_detail_relations),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = KitsugiColors.TextPrimary
                            )

                            when (val relsState = relationsState) {
                                is DetailTabState.Loading -> {
                                    DetailTvRelationsRailSkeleton(itemCount = 4)
                                }
                                is DetailTabState.Success -> {
                                    val relations = relsState.data
                                    if (relations.isEmpty()) {
                                        Text(
                                            text = stringResource(R.string.tv_detail_relations_empty),
                                            color = KitsugiColors.TextMuted,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    } else {
                                        LazyRow(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .focusRequester(relationsRowFocusRequester)
                                                .focusRestorer()
                                                .focusGroup()
                                                .focusProperties {
                                                    up = when {
                                                        hasStaffRow      -> staffRowFocusRequester
                                                        hasCharactersRow -> charactersRowFocusRequester
                                                        hasThemesRow     -> themesRowFocusRequester
                                                        !isMovie && hasEpisodesRow -> episodesRowFocusRequester
                                                        else             -> playButtonFocusRequester
                                                    }
                                                    down = when {
                                                        hasStatsRow    -> statsRowFocusRequester
                                                        hasReviewsRow  -> reviewsRowFocusRequester
                                                        else           -> FocusRequester.Cancel
                                                    }
                                                },
                                            horizontalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.itemGap),
                                            contentPadding = PaddingValues(vertical = 4.dp)
                                        ) {
                                            items(relations) { rel ->
                                                TvRelationCard(
                                                    relation = rel,
                                                    titleLanguage = titleLanguage,
                                                    onClick = {
                                                        val relResult = JikanSearchResult(
                                                            source = rel.source,
                                                            malId = rel.malId,
                                                            title = rel.title,
                                                            subtitle = "",
                                                            type = when (rel.mediaType) {
                                                                MediaType.Manga -> MediaType.Manga
                                                                MediaType.Movie -> MediaType.Movie
                                                                MediaType.TvShow -> MediaType.TvShow
                                                                else -> MediaType.Anime
                                                            },
                                                            total = null,
                                                            score = null,
                                                            isAdult = false,
                                                            imageUrl = rel.imageUrl,
                                                            year = null,
                                                            titleEnglish = rel.titleEnglish,
                                                            titleJapanese = rel.titleJapanese,
                                                            titleRomaji = rel.titleRomaji,
                                                            bangumiSubjectType = rel.bangumiSubjectType
                                                        )
                                                        onNavigateToRelationDetail(relResult)
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                                else -> {}
                            }
                        }
                    }

                    // --- Opening & Ending Themes Section ---
                    if (hasThemesRow) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.sm)) {
                                Text(
                                    text = stringResource(R.string.inline_opening_and_ending_videos_856c41d),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = KitsugiColors.TextPrimary
                                )

                                val themesList = remember(detailState) {
                                    val ops = detailState?.openings.orEmpty().map { it to true }
                                    val eds = detailState?.endings.orEmpty().map { it to false }
                                    ops + eds
                                }

                                LazyRow(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .focusRequester(themesRowFocusRequester)
                                        .focusRestorer()
                                        .focusGroup()
                                        .focusProperties {
                                            up = when {
                                                !isMovie && hasEpisodesRow -> episodesRowFocusRequester
                                                hasSeasonTabs              -> seasonTabsFocusRequester
                                                else                       -> playButtonFocusRequester
                                            }
                                            down = when {
                                                hasCharactersRow -> charactersRowFocusRequester
                                                hasStaffRow      -> staffRowFocusRequester
                                                hasRelationsRow  -> relationsRowFocusRequester
                                                else             -> FocusRequester.Cancel
                                            }
                                        },
                                    horizontalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.itemGap),
                                    contentPadding = PaddingValues(vertical = 4.dp)
                                ) {
                                    itemsIndexed(themesList) { index, pair ->
                                        val theme = pair.first
                                        val isOp = pair.second
                                        val themeIdx = if (isOp) {
                                            detailState?.openings.orEmpty().indexOf(theme)
                                        } else {
                                            detailState?.endings.orEmpty().indexOf(theme)
                                        }

                                        TvThemeCard(
                                            theme = theme,
                                            isOpening = isOp,
                                            index = themeIdx.coerceAtLeast(0),
                                            accentColor = accentColor,
                                            onClick = {
                                                if (!theme.videoUrl.isNullOrBlank()) {
                                                    com.kitsugi.animelist.core.player.TvTrailerPlayerPoolHolder.get(context).yield()
                                                    trailerPlaybackSource = com.kitsugi.animelist.data.trailer.TrailerPlaybackSource(
                                                        videoUrl = theme.videoUrl,
                                                        audioUrl = null
                                                    )
                                                    trailerOverlayTitle = theme.label
                                                    trailerLoading = false
                                                    trailerError = null
                                                    showTrailerOverlay = true
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // --- Stats Section ---
                    when (val currentStats = statsState) {
                        is DetailTabState.Loading -> item {
                            Column(verticalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.sm)) {
                                Text(
                                    text = stringResource(R.string.istatistikler),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = KitsugiColors.TextPrimary
                                )
                                DetailStatsLoadingSkeleton()
                            }
                        }
                        is DetailTabState.Success -> currentStats.data?.let { statsData ->
                            item {
                                TvStatsSection(
                                    stats = statsData,
                                    source = displayResult.source,
                                    focusRequester = statsRowFocusRequester,
                                    focusUp = when {
                                        hasRelationsRow  -> relationsRowFocusRequester
                                        hasStaffRow      -> staffRowFocusRequester
                                        hasCharactersRow -> charactersRowFocusRequester
                                        hasThemesRow     -> themesRowFocusRequester
                                        !isMovie && hasEpisodesRow -> episodesRowFocusRequester
                                        else             -> playButtonFocusRequester
                                    },
                                    focusDown = if (hasReviewsRow) reviewsRowFocusRequester else FocusRequester.Cancel
                                )
                            }
                        }
                        else -> Unit
                    }

                    // --- Reviews, Activities & Forum Topics Section ---
                    item {
                        TvReviewsTabContent(
                            state = reviewsState as? DetailTabState<List<KitsugiReview>>
                                ?: DetailTabState.Loading,
                            source = displayResult.source,
                            externalId = displayResult.malId ?: 0,
                            mediaType = displayResult.type,
                            apiClient = apiClient,
                            tmdbId = displayResult.tmdbId ?: detailState?.tmdbId,
                            realMalId = displayResult.realMalId ?: detailState?.realMalId,
                            titleLanguage = titleLanguage,
                            focusRequester = reviewsRowFocusRequester,
                            focusUp = when {
                                hasStatsRow     -> statsRowFocusRequester
                                hasRelationsRow -> relationsRowFocusRequester
                                hasStaffRow     -> staffRowFocusRequester
                                hasCharactersRow -> charactersRowFocusRequester
                                else            -> playButtonFocusRequester
                            },
                            focusDown = FocusRequester.Cancel
                        )
                    }

                    // --- Fandom Wiki (açılır kart) ---
                    item(key = "fandom_wiki") {
                        MediaWikiSectionCard(
                            viewModel = wikiViewModel,
                            query = wikiQuery,
                            accentColor = accentColor,
                            title = stringResource(R.string.fandom_tv_wiki_title),
                            hint = stringResource(R.string.fandom_manga_wiki_hint),
                            modifier = Modifier.padding(top = KitsugiTvTokens.Spacing.xl)
                        )
                    }
                }
            }


            // Auto focus play button on start
            LaunchedEffect(Unit) {
                playButtonFocusRequester.safeRequestFocus()
            }

            if (showTrailerOverlay) {
                com.kitsugi.animelist.ui.tv.components.TvSharedTrailerOverlay(
                    title = if (trailerOverlayTitle.isNotBlank()) trailerOverlayTitle else displayTitle,
                    playbackSource = trailerPlaybackSource,
                    isLoading = trailerLoading,
                    errorMessage = trailerError,
                    onDismiss = {
                        showTrailerOverlay = false
                    },
                    onRetry = {
                        if (trailerOverlayTitle == displayTitle) {
                            loadAndShowTrailer()
                        } else {
                            val currentSource = trailerPlaybackSource
                            if (currentSource != null) {
                                trailerPlaybackSource = null
                                scope.launch {
                                    delay(200)
                                    trailerPlaybackSource = currentSource
                                }
                            }
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun BadgeText(text: String, color: Color = KitsugiColors.TextMuted) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(KitsugiColors.SurfaceStrong)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = color
        )
    }
}

@Composable
private fun TvActionButton(
    onClick: () -> Unit,
    focusRequester: FocusRequester,
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    backgroundColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    var isFocused by remember { mutableStateOf(false) }
    val isPrimary = backgroundColor != KitsugiColors.SurfaceStrong

    if (isPrimary) {
        KitsugiUiverseGlowButton(
            onClick = onClick,
            shape = RoundedCornerShape(12.dp),
            contentPadding = 12.dp,
            modifier = modifier
                .focusRequester(focusRequester)
                .onFocusChanged { isFocused = it.isFocused }
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
        }
        return
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(backgroundColor)
            .border(
                BorderStroke(
                    width = if (isFocused) KitsugiTvTokens.Cards.focusedBorderWidth else 0.dp,
                    color = if (isFocused) Color.White else Color.Transparent
                ),
                shape = RoundedCornerShape(12.dp)
            )
            .focusRequester(focusRequester)
            .onFocusChanged { isFocused = it.isFocused }
            .tvClickable(shape = RoundedCornerShape(12.dp), onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = textColor
            )
        }
    }
}

@Composable
private fun TvEpisodeCard(
    episode: KitsugiStreamingEpisode,
    index: Int,
    accentColor: Color,
    rating: Double?,
    isWatched: Boolean,
    isAdult: Boolean = false,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    val blurRadius = if (!isWatched && index > 0 && !isFocused) 16.dp else 0.dp

    Column(
        modifier = Modifier
            .width(KitsugiTvTokens.Cards.episodeWidth)
            .clip(KitsugiTvTokens.Shapes.backdropCard)
            .background(KitsugiColors.Surface)
            .border(
                BorderStroke(
                    width = if (isFocused) KitsugiTvTokens.Cards.focusedBorderWidth else 0.dp,
                    color = if (isFocused) accentColor else Color.Transparent
                ),
                shape = KitsugiTvTokens.Shapes.backdropCard
            )
            .onFocusChanged { isFocused = it.isFocused }
            .tvClickable(shape = KitsugiTvTokens.Shapes.backdropCard, onClick = onClick)
    ) {
        // Thumbnail Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .background(KitsugiColors.SurfaceStrong),
            contentAlignment = Alignment.Center
        ) {
            if (!episode.thumbnail.isNullOrBlank()) {
                com.kitsugi.animelist.ui.components.KitsugiNsfwImage(
                    model = episode.thumbnail,
                    contentDescription = episode.title,
                    isAdult = isAdult,
                    modifier = Modifier
                        .fillMaxSize()
                        .safeBlur(blurRadius),
                    contentScale = ContentScale.Crop
                )
            } else {
                Text(
                    text = "${index + 1}",
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
                    color = accentColor.copy(alpha = 0.5f)
                )
            }

            // Blur Overlay text if blurred
            if (blurRadius > 0.dp) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.4f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Spoiler",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White.copy(alpha = 0.9f),
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Top Status Badges (Watched and IMDb)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isWatched) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF2E7D32), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.tv_detail_episode_watched),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                if (rating != null && rating > 0.0) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFFFFB300), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.StarSolid,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(9.dp)
                            )
                            Text(
                                text = "%.1f".format(rating),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.Black
                            )
                        }
                    }
                }
            }
        }

        // Details Row
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = stringResource(R.string.tv_detail_episode_label, index + 1),
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = accentColor
            )
            Text(
                text = episode.title,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                color = KitsugiColors.TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!episode.site.isNullOrBlank()) {
                Text(
                    text = episode.site ?: "",
                    style = MaterialTheme.typography.labelSmall,
                    color = KitsugiColors.TextMuted
                )
            }
        }
    }
}

@Composable
private fun TvCharacterCard(
    character: KitsugiCharacter,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .width(100.dp)
            .tvClickable(shape = RoundedCornerShape(10.dp), onClick = onClick)
            .onFocusChanged { isFocused = it.isFocused },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AsyncImage(
            model = character.imageUrl,
            contentDescription = character.name,
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(36.dp))
                .background(KitsugiColors.SurfaceStrong)
                .border(
                    BorderStroke(
                        width = if (isFocused) KitsugiTvTokens.Cards.focusedBorderWidth else 0.dp,
                        color = if (isFocused) Color.White else Color.Transparent
                    ),
                    shape = RoundedCornerShape(36.dp)
                ),
            contentScale = ContentScale.Crop
        )

        Text(
            text = character.name,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = KitsugiColors.TextPrimary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun TvStaffCard(
    staff: KitsugiStaff,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .width(100.dp)
            .tvClickable(shape = RoundedCornerShape(10.dp), onClick = onClick)
            .onFocusChanged { isFocused = it.isFocused },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AsyncImage(
            model = staff.imageUrl,
            contentDescription = staff.name,
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(36.dp))
                .background(KitsugiColors.SurfaceStrong)
                .border(
                    BorderStroke(
                        width = if (isFocused) KitsugiTvTokens.Cards.focusedBorderWidth else 0.dp,
                        color = if (isFocused) Color.White else Color.Transparent
                    ),
                    shape = RoundedCornerShape(36.dp)
                ),
            contentScale = ContentScale.Crop
        )

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = staff.name,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = KitsugiColors.TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
            Text(
                text = staff.role.toTurkishStaffRole(),
                style = MaterialTheme.typography.labelSmall,
                color = KitsugiColors.TextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun TvRelationCard(
    relation: KitsugiRelation,
    titleLanguage: String,
    onClick: () -> Unit
) {
    val displayTitle = relation.getDisplayTitle(titleLanguage)
    var isFocused by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .width(110.dp)
            .onFocusChanged { isFocused = it.isFocused }
            .tvClickable(shape = RoundedCornerShape(10.dp), onClick = onClick),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        com.kitsugi.animelist.ui.components.KitsugiNsfwImage(
            model = relation.imageUrl,
            contentDescription = displayTitle,
            isAdult = relation.isAdult,
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(KitsugiColors.SurfaceStrong)
                .border(
                    BorderStroke(
                        width = if (isFocused) KitsugiTvTokens.Cards.focusedBorderWidth else 0.dp,
                        color = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp)
                ),
            contentScale = ContentScale.Crop
        )

        Text(
            text = displayTitle,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = KitsugiColors.TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = relation.relationType,
            style = MaterialTheme.typography.labelSmall,
            color = KitsugiColors.TextMuted,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// ---------------------------------------------------------------------------
//  TV Stats Section
// ---------------------------------------------------------------------------

@Composable
private fun TvStatsSection(
    stats: KitsugiStats,
    source: String,
    focusRequester: FocusRequester,
    focusUp: FocusRequester,
    focusDown: FocusRequester
) {
    val accentColor = LocalKitsugiAccent.current
    val isTmdb = source.equals("tmdb", ignoreCase = true) || source.equals("simkl", ignoreCase = true)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .focusRequester(focusRequester)
            .focusProperties {
                up   = focusUp
                down = focusDown
            },
        verticalArrangement = Arrangement.spacedBy(KitsugiTvTokens.Spacing.sm)
    ) {
        Text(
            text = stringResource(R.string.istatistikler),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = KitsugiColors.TextPrimary
        )

        val hasWatching = stats.watching != null && stats.watching > 0
        val hasCompleted = stats.completed != null && stats.completed > 0
        val hasPlanned = stats.planned != null && stats.planned > 0
        val hasDropped = stats.dropped != null && stats.dropped > 0
        val total = ((stats.watching ?: 0) + (stats.completed ?: 0) +
            (stats.planned ?: 0) + (stats.dropped ?: 0)).coerceAtLeast(1)

        if (hasWatching || hasCompleted || hasPlanned || hasDropped) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (hasWatching) {
                    TvStatChip(
                        label = if (isTmdb) stringResource(R.string.populerlik) else stringResource(R.string.watch_watching),
                        count = stats.watching ?: 0,
                        total = total,
                        color = KitsugiColors.AccentBlue,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (hasCompleted) {
                    TvStatChip(
                        label = if (isTmdb) "Oylar" else stringResource(R.string.cs_diag_completed),
                        count = stats.completed ?: 0,
                        total = total,
                        color = KitsugiColors.AccentGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (hasPlanned) {
                    TvStatChip(
                        label = stringResource(R.string.planlandi),
                        count = stats.planned ?: 0,
                        total = total,
                        color = KitsugiColors.AccentOrange,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (hasDropped) {
                    TvStatChip(
                        label = stringResource(R.string.birakildi),
                        count = stats.dropped ?: 0,
                        total = total,
                        color = KitsugiColors.AccentRed,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        if (stats.scoreDistribution.isNotEmpty()) {
            val sorted = stats.scoreDistribution.sortedByDescending { it.score }
            val maxVotes = sorted.maxOfOrNull { it.amount }?.coerceAtLeast(1) ?: 1
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(KitsugiColors.Surface)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = stringResource(R.string.puan_dagilimi),
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = KitsugiColors.TextPrimary
                )
                sorted.forEach { s ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        KitsugiEmojiLabel(
                            label = "${s.score}",
                            icon = Icons.StarSolid,
                            iconSize = 9.dp,
                            color = KitsugiColors.TextSecondary,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(30.dp)
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(KitsugiColors.SurfaceStrong)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(s.amount.toFloat() / maxVotes)
                                    .background(accentColor)
                            )
                        }
                        Text(
                            text = s.amount.toString(),
                            color = KitsugiColors.TextMuted,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.width(40.dp),
                            textAlign = TextAlign.End
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TvStatChip(
    label: String,
    count: Int,
    total: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    val pct = (count.toFloat() / total * 100).toInt()
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(KitsugiColors.Surface)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = label,
            color = KitsugiColors.TextMuted,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = count.toString(),
            color = color,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Black)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(KitsugiColors.SurfaceStrong)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(pct / 100f)
                    .background(color)
            )
        }
    }
}

// ---------------------------------------------------------------------------
//  TV Review Card (D-pad optimize, BottomSheet'siz)
// ---------------------------------------------------------------------------

@Composable
private fun TvReviewCard(review: KitsugiReview) {
    var isFocused by remember { mutableStateOf(false) }
    val accentColor = LocalKitsugiAccent.current

    Column(
        modifier = Modifier
            .width(300.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(KitsugiColors.Surface)
            .border(
                BorderStroke(
                    width = if (isFocused) KitsugiTvTokens.Cards.focusedBorderWidth else 0.dp,
                    color = if (isFocused) Color.White else Color.Transparent
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .onFocusChanged { isFocused = it.isFocused }
            .tvClickable(shape = RoundedCornerShape(16.dp), onClick = {})
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Header: avatar + username + score
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(KitsugiColors.SurfaceStrong),
                contentAlignment = Alignment.Center
            ) {
                if (!review.avatarUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = review.avatarUrl,
                        contentDescription = review.username,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Text(
                        text = review.username.take(1).uppercase(),
                        color = accentColor,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Black
                    )
                }
            }
            Text(
                text = review.username,
                color = KitsugiColors.TextPrimary,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (review.score != null && review.score > 0) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(accentColor.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "${review.score}/10",
                        color = accentColor,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        // Summary
        Text(
            text = review.summary,
            color = KitsugiColors.TextSecondary,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 4,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 18.sp
        )

        // Date + helpful
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!review.dateText.isNullOrBlank()) {
                Text(
                    text = review.dateText,
                    color = KitsugiColors.TextMuted,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            if (review.helpfulCount != null && review.helpfulCount > 0) {
                KitsugiEmojiLabel(
                    label = "${review.helpfulCount}",
                    icon = Icons.ThumbsUp,
                    iconSize = 10.dp,
                    color = KitsugiColors.TextMuted,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

@Composable
private fun TvThemeCard(
    theme: com.kitsugi.animelist.data.remote.KitsugiTheme,
    isOpening: Boolean,
    index: Int,
    accentColor: Color,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .width(220.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(KitsugiColors.Surface)
            .border(
                BorderStroke(
                    width = if (isFocused) KitsugiTvTokens.Cards.focusedBorderWidth else 0.dp,
                    color = if (isFocused) accentColor else Color.Transparent
                ),
                shape = RoundedCornerShape(12.dp)
            )
            .onFocusChanged { isFocused = it.isFocused }
            .tvClickable(shape = RoundedCornerShape(12.dp), onClick = onClick)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.PlayArrow,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column {
                Text(
                    text = if (isOpening) stringResource(R.string.acilis_temasi_x, index + 1) else stringResource(R.string.kapanis_temasi_x, index + 1),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = accentColor
                )
                Text(
                    text = "Uygulamada Oynat",
                    style = MaterialTheme.typography.labelSmall,
                    color = KitsugiColors.TextMuted
                )
            }
        }

        Text(
            text = theme.label,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
            color = KitsugiColors.TextPrimary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            minLines = 2
        )
    }
}
