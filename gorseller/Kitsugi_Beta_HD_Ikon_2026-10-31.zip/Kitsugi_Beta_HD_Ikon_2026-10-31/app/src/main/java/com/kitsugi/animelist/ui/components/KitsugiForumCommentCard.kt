package com.kitsugi.animelist.ui.components

import android.content.Context
import android.widget.Toast
import com.kitsugi.animelist.ui.theme.gradient.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import com.kitsugi.animelist.ui.icons.KitsugiIcons as Icons
import com.kitsugi.animelist.ui.theme.gradient.Icon
import androidx.compose.material3.IconButton
import com.kitsugi.animelist.ui.theme.gradient.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.kitsugi.animelist.data.remote.JikanApiClient
import com.kitsugi.animelist.data.remote.KitsugiForumReply
import com.kitsugi.animelist.ui.theme.LocalKitsugiAccent
import com.kitsugi.animelist.ui.theme.KitsugiColors
import com.kitsugi.animelist.ui.utils.tvClickable
import com.kitsugi.animelist.utils.KitsugiTranslateUtils.openTranslator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.ui.res.stringResource
import com.kitsugi.animelist.R
import com.kitsugi.animelist.utils.KitsugiStrings

/**
 * A single forum comment/reply card used inside topic detail sheets,
 * supporting recursive rendering of child comments.
 */
@Composable
internal fun KitsugiForumCommentCard(
    comment: KitsugiForumReply,
    displayText: String,
    apiClient: JikanApiClient,
    coroutineScope: CoroutineScope,
    selectedLanguage: String = "original",
    translatedComments: Map<Int, String> = emptyMap(),
    commentSource: String = "anilist",
    /** Yorum çevirisi sürüyor mu — çeviri butonu bu sırada yüklenme animasyonu gösterir. */
    isTranslating: Boolean = false,
    onUserProfileClick: ((userId: Int?, username: String, avatarUrl: String?, source: String) -> Unit)? = null,
    onReplyClick: ((KitsugiForumReply) -> Unit)? = null
) {
    val accentColor = LocalKitsugiAccent.current
    val context = LocalContext.current

    var isLikedState by remember { mutableStateOf(comment.isLiked) }
    var likeCountState by remember { mutableStateOf(comment.likeCount) }
    var isRepliesExpanded by remember { mutableStateOf(false) }

    // ── Flat AniHyou-style layout: no card background, clean separator line ──
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 16.dp)
    ) {
        // ── Author row: avatar · username (left)  date (right) ──
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = if (onUserProfileClick != null) {
                    Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onUserProfileClick(comment.userId, comment.username, comment.avatarUrl, commentSource) }
                        .padding(end = 4.dp, top = 2.dp, bottom = 2.dp)
                } else Modifier
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(KitsugiColors.SurfaceSoft)
                ) {
                    if (!comment.avatarUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = comment.avatarUrl,
                            contentDescription = comment.username,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                text = comment.username.take(1).uppercase(),
                                color = KitsugiColors.TextMuted,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = comment.username,
                    color = KitsugiColors.TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text(
                text = getRelativeTime(comment.createdAt, comment.dateText),
                color = KitsugiColors.TextSecondary,
                fontSize = 13.sp
            )
        }

        // ── Body: markdown content ──
        var activeGalleryImages by remember { mutableStateOf<List<String>>(emptyList()) }
        var activeGalleryIndex by remember { mutableStateOf(0) }

        KitsugiMarkdownText(
            text = displayText,
            modifier = Modifier.padding(vertical = 8.dp),
            onImageGalleryRequest = { urls, index ->
                activeGalleryImages = urls
                activeGalleryIndex = index
            }
        )

        if (activeGalleryImages.isNotEmpty()) {
            KitsugiImageGalleryDialog(
                imageUrls = activeGalleryImages,
                initialIndex = activeGalleryIndex,
                title = comment.username,
                onDismiss = { activeGalleryImages = emptyList() }
            )
        }

        // ── Actions row: (Translate · Copy)  |  (Replies · Like · Reply) ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left micro-actions: Translate & Copy
            Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                KitsugiTranslateIconButton(
                    onClick = { context.openTranslator(comment.comment) },
                    modifier = Modifier.size(28.dp),
                    tint = accentColor,
                    contentDescription = stringResource(R.string.cevir),
                    iconSize = 15.dp,
                    isLoading = isTranslating,
                    ringSize = 24.dp
                )
                IconButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("comment_text", comment.comment))
                        Toast.makeText(context, KitsugiStrings.get(R.string.toast_copied_clipboard), Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.ContentCopy,
                        contentDescription = stringResource(R.string.action_copy),
                        tint = KitsugiColors.TextSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }

            // Right stat-actions: child replies toggle · like · reply
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (comment.childComments.isNotEmpty()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { isRepliesExpanded = !isRepliesExpanded }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = if (isRepliesExpanded) Icons.ChatBubble else Icons.ChatBubbleOutline,
                            contentDescription = stringResource(R.string.yanitlar),
                            tint = accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = comment.childComments.size.toString(),
                            color = KitsugiColors.TextSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Like button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            coroutineScope.launch {
                                val success = apiClient.toggleLike(comment.id, "THREAD_COMMENT")
                                if (success) {
                                    isLikedState = !isLikedState
                                    likeCountState = if (isLikedState) likeCountState + 1 else likeCountState - 1
                                } else {
                                    Toast.makeText(context, KitsugiStrings.get(R.string.lutfen_once_giris_yapin), Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = if (isLikedState) Icons.Favorite else Icons.FavoriteBorder,
                        contentDescription = stringResource(R.string.begen),
                        tint = if (isLikedState) accentColor else KitsugiColors.TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = likeCountState.toString(),
                        color = KitsugiColors.TextSecondary,
                        fontSize = 13.sp
                    )
                }

                // Reply button
                if (onReplyClick != null) {
                    IconButton(
                        onClick = { onReplyClick(comment) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Reply,
                            contentDescription = stringResource(R.string.yanitla),
                            tint = KitsugiColors.TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // ── Separator line (AniHyou style) ──
        androidx.compose.material3.HorizontalDivider(
            color = KitsugiColors.Border.copy(alpha = 0.25f),
            thickness = 0.6.dp
        )

        // ── Child replies with VerticalDivider indent (already AniHyou-style) ──
        if (isRepliesExpanded && comment.childComments.isNotEmpty()) {
            comment.childComments.forEach { child ->
                KitsugiForumChildCommentRow(
                    comment = child,
                    modifier = Modifier.padding(start = 0.dp),
                    apiClient = apiClient,
                    coroutineScope = coroutineScope,
                    selectedLanguage = selectedLanguage,
                    translatedComments = translatedComments,
                    commentSource = commentSource,
                    isTranslating = isTranslating,
                    onUserProfileClick = onUserProfileClick,
                    onReplyClick = onReplyClick
                )
            }
        }
    }
}

@Composable
private fun KitsugiForumChildCommentRow(
    comment: KitsugiForumReply,
    modifier: Modifier = Modifier,
    apiClient: JikanApiClient,
    coroutineScope: CoroutineScope,
    selectedLanguage: String,
    translatedComments: Map<Int, String>,
    commentSource: String = "anilist",
    isTranslating: Boolean = false,
    onUserProfileClick: ((userId: Int?, username: String, avatarUrl: String?, source: String) -> Unit)?,
    onReplyClick: ((KitsugiForumReply) -> Unit)?
) {
    val accentColor = LocalKitsugiAccent.current
    val context = LocalContext.current
    var isLikedState by remember { mutableStateOf(comment.isLiked) }
    var likeCountState by remember { mutableStateOf(comment.likeCount) }
    var isRepliesExpanded by remember { mutableStateOf(false) }

    Row(
        modifier = modifier
            .padding(top = 10.dp)
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
    ) {
        // Indentation line
        androidx.compose.material3.VerticalDivider(
            modifier = Modifier.padding(end = 16.dp),
            color = KitsugiColors.SurfaceSoft
        )

        Column(
            modifier = Modifier.weight(1f)
        ) {
            // Author info
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = if (onUserProfileClick != null) {
                        Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onUserProfileClick(comment.userId, comment.username, comment.avatarUrl, commentSource) }
                            .padding(vertical = 2.dp)
                    } else Modifier
                ) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(KitsugiColors.SurfaceSoft)
                    ) {
                        if (!comment.avatarUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = comment.avatarUrl,
                                contentDescription = comment.username,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(
                                    text = comment.username.take(1).uppercase(),
                                    color = KitsugiColors.TextMuted,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = comment.username,
                        color = KitsugiColors.TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = getRelativeTime(comment.createdAt, comment.dateText),
                    color = KitsugiColors.TextSecondary,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Body
            val displayComment = if (selectedLanguage == "turkish") {
                translatedComments[comment.id] ?: comment.comment
            } else {
                comment.comment
            }

            var activeGalleryImages by remember { mutableStateOf<List<String>>(emptyList()) }
            var activeGalleryIndex by remember { mutableStateOf(0) }

            KitsugiMarkdownText(
                text = displayComment,
                onImageGalleryRequest = { urls, index ->
                    activeGalleryImages = urls
                    activeGalleryIndex = index
                }
            )

            if (activeGalleryImages.isNotEmpty()) {
                KitsugiImageGalleryDialog(
                    imageUrls = activeGalleryImages,
                    initialIndex = activeGalleryIndex,
                    title = comment.username,
                    onDismiss = { activeGalleryImages = emptyList() }
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Actions (Translate, Copy, Reply, Like, Nested Replies)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    KitsugiTranslateIconButton(
                        onClick = { context.openTranslator(comment.comment) },
                        modifier = Modifier.size(24.dp),
                        tint = accentColor,
                        contentDescription = stringResource(R.string.cevir),
                        iconSize = 14.dp,
                        isLoading = isTranslating,
                        ringSize = 22.dp
                    )
                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("comment_text", comment.comment))
                            Toast.makeText(context, KitsugiStrings.get(R.string.toast_copied_clipboard), Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.ContentCopy,
                            contentDescription = stringResource(R.string.action_copy),
                            tint = KitsugiColors.TextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (comment.childComments.isNotEmpty()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { isRepliesExpanded = !isRepliesExpanded }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                          Icon(
                              imageVector = if (isRepliesExpanded) Icons.ChatBubble else Icons.ChatBubbleOutline,
                              contentDescription = stringResource(R.string.yanitlar),
                              tint = accentColor,
                              modifier = Modifier.size(14.dp)
                          )
                          Spacer(modifier = Modifier.width(4.dp))
                          Text(
                              text = comment.childComments.size.toString(),
                              color = KitsugiColors.TextSecondary,
                              fontSize = 12.sp,
                              fontWeight = FontWeight.Bold
                          )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable {
                                coroutineScope.launch {
                                    val success = apiClient.toggleLike(comment.id, "THREAD_COMMENT")
                                    if (success) {
                                        isLikedState = !isLikedState
                                        likeCountState = if (isLikedState) likeCountState + 1 else likeCountState - 1
                                    } else {
                                        Toast.makeText(context, KitsugiStrings.get(R.string.lutfen_once_giris_yapin), Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = if (isLikedState) Icons.Favorite else Icons.FavoriteBorder,
                            contentDescription = stringResource(R.string.begen),
                            tint = if (isLikedState) accentColor else KitsugiColors.TextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = likeCountState.toString(),
                            color = KitsugiColors.TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    if (onReplyClick != null) {
                        IconButton(
                            onClick = { onReplyClick(comment) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Reply,
                                contentDescription = stringResource(R.string.yanitla),
                                tint = KitsugiColors.TextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (isRepliesExpanded && comment.childComments.isNotEmpty()) {
        comment.childComments.forEach { child ->
            KitsugiForumChildCommentRow(
                comment = child,
                modifier = Modifier.padding(start = 16.dp),
                apiClient = apiClient,
                coroutineScope = coroutineScope,
                selectedLanguage = selectedLanguage,
                translatedComments = translatedComments,
                commentSource = commentSource,
                isTranslating = isTranslating,
                onUserProfileClick = onUserProfileClick,
                onReplyClick = onReplyClick
            )
        }
    }
}

private fun getRelativeTime(createdAt: Int?, fallback: String?): String {
    if (createdAt == null || createdAt <= 0) return fallback.orEmpty()
    val diffMillis = System.currentTimeMillis() - (createdAt * 1000L)
    val diffSeconds = diffMillis / 1000L
    return when {
        diffSeconds < 0 -> "Şimdi"
        diffSeconds < 60 -> "Şimdi"
        diffSeconds < 3600 -> "${diffSeconds / 60}d önce"
        diffSeconds < 86400 -> "${diffSeconds / 3600}sa önce"
        diffSeconds < 604800 -> "${diffSeconds / 86400}g önce"
        else -> {
            val sdf = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault())
            sdf.format(java.util.Date(createdAt * 1000L))
        }
    }
}
